@echo off
chcp 65001 >nul
title PlantManager Print Agent - Instalator

echo ============================================
echo   PlantManager Print Agent - Instalator
echo ============================================
echo.

:: Sprawdz czy Node.js jest zainstalowany
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [BLAD] Node.js nie jest zainstalowany!
    echo.
    echo Pobierz Node.js ze strony: https://nodejs.org/
    echo Zainstaluj wersje LTS i uruchom ten skrypt ponownie.
    echo.
    pause
    exit /b 1
)

echo [OK] Node.js znaleziony
for /f "tokens=*" %%i in ('node --version') do echo     Wersja: %%i
echo.

:: Instaluj zaleznosci
echo [INFO] Instalowanie zaleznosci...
call npm install --production
if %ERRORLEVEL% NEQ 0 (
    echo [BLAD] Nie udalo sie zainstalowac zaleznosci!
    pause
    exit /b 1
)
echo [OK] Zaleznosci zainstalowane
echo.

:: Sprawdz czy istnieje config.json
if not exist "config.json" (
    echo [INFO] Tworzenie pliku konfiguracyjnego...
    echo {> config.json
    echo   "serverUrl": "https://polflor.fast-site.pl",>> config.json
    echo   "apiKey": "WPISZ_SWOJ_KLUCZ_API",>> config.json
    echo   "printerName": "",>> config.json
    echo   "pollInterval": 3000>> config.json
    echo }>> config.json
    echo.
    echo [UWAGA] Edytuj plik config.json i wpisz swoj klucz API!
    echo         Klucz znajdziesz w Ustawieniach -^> Drukarki
    echo.
    notepad config.json
    pause
)

:: Uruchom agenta
echo [INFO] Uruchamianie Print Agent...
echo.
echo ============================================
echo   Agent dziala. Nie zamykaj tego okna!
echo   Aby zatrzymac, nacisnij Ctrl+C
echo ============================================
echo.
node dist/index.js
pause
