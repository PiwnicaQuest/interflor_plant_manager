#!/bin/bash

# =============================================================================
# PrintBroker - macOS Installer
# Polflor Plant Management System
# =============================================================================

set -e

# Colors for output
RED="\033[0;31m"
GREEN="\033[0;32m"
YELLOW="\033[1;33m"
BLUE="\033[0;34m"
NC="\033[0m" # No Color

# Configuration
INSTALL_DIR="$HOME/PrintBroker"
BROKER_PORT=3005
LAUNCHAGENT_NAME="com.polflor.printbroker"
LAUNCHAGENT_DIR="$HOME/Library/LaunchAgents"
LAUNCHAGENT_PLIST="$LAUNCHAGENT_DIR/$LAUNCHAGENT_NAME.plist"

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo ""
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                                                                ║${NC}"
echo -e "${BLUE}║   ${GREEN}🖨️  PrintBroker - macOS Installer${BLUE}                           ║${NC}"
echo -e "${BLUE}║   ${NC}Polflor Plant Management System${BLUE}                              ║${NC}"
echo -e "${BLUE}║                                                                ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to install Homebrew
install_homebrew() {
    echo -e "${YELLOW}Installing Homebrew...${NC}"
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    
    # Add Homebrew to PATH for Apple Silicon Macs
    if [[ $(uname -m) == "arm64" ]]; then
        echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> "$HOME/.zprofile"
        eval "$(/opt/homebrew/bin/brew shellenv)"
    fi
}

# Function to install Node.js
install_nodejs() {
    echo -e "${YELLOW}Installing Node.js...${NC}"
    
    if command_exists brew; then
        brew install node
    else
        # Download and install Node.js directly
        echo -e "${YELLOW}Downloading Node.js installer...${NC}"
        NODE_PKG="node-v20.11.0.pkg"
        curl -o "/tmp/$NODE_PKG" "https://nodejs.org/dist/v20.11.0/node-v20.11.0.pkg"
        
        echo -e "${YELLOW}Installing Node.js (requires admin password)...${NC}"
        sudo installer -pkg "/tmp/$NODE_PKG" -target /
        rm "/tmp/$NODE_PKG"
    fi
}

# Step 1: Check Node.js
echo -e "${BLUE}[1/6]${NC} Checking Node.js installation..."

if command_exists node; then
    NODE_VERSION=$(node -v)
    echo -e "  ${GREEN}✓${NC} Node.js found: $NODE_VERSION"
else
    echo -e "  ${YELLOW}⚠${NC} Node.js not found"
    
    # Check for Homebrew
    if ! command_exists brew; then
        echo -e "  ${YELLOW}Installing Homebrew first...${NC}"
        install_homebrew
    fi
    
    install_nodejs
    
    if command_exists node; then
        NODE_VERSION=$(node -v)
        echo -e "  ${GREEN}✓${NC} Node.js installed: $NODE_VERSION"
    else
        echo -e "  ${RED}✗${NC} Failed to install Node.js"
        echo -e "  Please install Node.js manually from: https://nodejs.org/"
        exit 1
    fi
fi

# Step 2: Create installation directory
echo -e "${BLUE}[2/6]${NC} Creating installation directory..."

if [ -d "$INSTALL_DIR" ]; then
    echo -e "  ${YELLOW}⚠${NC} Directory exists, backing up..."
    mv "$INSTALL_DIR" "$INSTALL_DIR.backup.$(date +%Y%m%d%H%M%S)"
fi

mkdir -p "$INSTALL_DIR"
echo -e "  ${GREEN}✓${NC} Created: $INSTALL_DIR"

# Step 3: Copy files
echo -e "${BLUE}[3/6]${NC} Copying files..."

# Copy source files
cp -r "$SCRIPT_DIR/src" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/config" "$INSTALL_DIR/" 2>/dev/null || mkdir -p "$INSTALL_DIR/config"
cp "$SCRIPT_DIR/package.json" "$INSTALL_DIR/"
cp "$SCRIPT_DIR/package-lock.json" "$INSTALL_DIR/" 2>/dev/null || true
cp "$SCRIPT_DIR/tsconfig.json" "$INSTALL_DIR/"

# Copy command scripts
cp "$SCRIPT_DIR/start.command" "$INSTALL_DIR/"
cp "$SCRIPT_DIR/stop.command" "$INSTALL_DIR/"
cp "$SCRIPT_DIR/uninstall.command" "$INSTALL_DIR/"

# Make scripts executable
chmod +x "$INSTALL_DIR/start.command"
chmod +x "$INSTALL_DIR/stop.command"
chmod +x "$INSTALL_DIR/uninstall.command"

echo -e "  ${GREEN}✓${NC} Files copied"

# Step 4: Install npm dependencies
echo -e "${BLUE}[4/6]${NC} Installing dependencies..."

cd "$INSTALL_DIR"
npm install --production=false
echo -e "  ${GREEN}✓${NC} Dependencies installed"

# Step 5: Compile TypeScript
echo -e "${BLUE}[5/6]${NC} Compiling TypeScript..."

npm run build
echo -e "  ${GREEN}✓${NC} Compilation complete"

# Step 6: Setup LaunchAgent for auto-start
echo -e "${BLUE}[6/6]${NC} Setting up auto-start..."

mkdir -p "$LAUNCHAGENT_DIR"

cat > "$LAUNCHAGENT_PLIST" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>$LAUNCHAGENT_NAME</string>
    <key>ProgramArguments</key>
    <array>
        <string>/usr/local/bin/node</string>
        <string>$INSTALL_DIR/dist/index.js</string>
    </array>
    <key>WorkingDirectory</key>
    <string>$INSTALL_DIR</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>$INSTALL_DIR/logs/broker.log</string>
    <key>StandardErrorPath</key>
    <string>$INSTALL_DIR/logs/broker-error.log</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/usr/local/bin:/usr/bin:/bin:/opt/homebrew/bin</string>
    </dict>
</dict>
</plist>
EOF

# Create logs directory
mkdir -p "$INSTALL_DIR/logs"

# Find correct node path
NODE_PATH=$(which node)
sed -i "" "s|/usr/local/bin/node|$NODE_PATH|g" "$LAUNCHAGENT_PLIST"

echo -e "  ${GREEN}✓${NC} LaunchAgent created"

# Load LaunchAgent
launchctl unload "$LAUNCHAGENT_PLIST" 2>/dev/null || true
launchctl load "$LAUNCHAGENT_PLIST"

echo -e "  ${GREEN}✓${NC} LaunchAgent loaded"

# Wait for service to start
sleep 2

# Check if broker is running
if curl -s "http://localhost:$BROKER_PORT/health" > /dev/null 2>&1; then
    echo -e "  ${GREEN}✓${NC} PrintBroker is running"
else
    echo -e "  ${YELLOW}⚠${NC} PrintBroker may need a moment to start"
fi

# Create desktop shortcut
DESKTOP_ALIAS="$HOME/Desktop/PrintBroker Start.command"
cat > "$DESKTOP_ALIAS" << EOF
#!/bin/bash
cd "$INSTALL_DIR"
./start.command
EOF
chmod +x "$DESKTOP_ALIAS"

echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                                ║${NC}"
echo -e "${GREEN}║   ✅ Installation Complete!                                    ║${NC}"
echo -e "${GREEN}║                                                                ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BLUE}Installation directory:${NC} $INSTALL_DIR"
echo -e "  ${BLUE}Broker URL:${NC} http://localhost:$BROKER_PORT"
echo ""
echo -e "  ${YELLOW}Commands:${NC}"
echo -e "    Start:     $INSTALL_DIR/start.command"
echo -e "    Stop:      $INSTALL_DIR/stop.command"
echo -e "    Uninstall: $INSTALL_DIR/uninstall.command"
echo ""
echo -e "  ${YELLOW}Test the broker:${NC}"
echo -e "    curl http://localhost:$BROKER_PORT/health"
echo ""
echo -e "  ${GREEN}PrintBroker will start automatically when you log in.${NC}"
echo ""

# Keep terminal open
read -p "Press Enter to close this window..."
